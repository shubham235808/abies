# ABIES Ayurveda Care — Clickable MVP Frontend

This is the first working website prototype for the ABIES Ayurveda Integrated Care Platform.

## Included journeys
- Public home / platform proposition
- Doctor discovery, filtering, doctor details and consultation booking
- Panchakarma discovery and slot requests
- Diagnostic packages, report upload prototype and cart
- Ayurveda medicine catalogue and prescription upload prototype
- Customer Care, Sales & Partnerships, Technical Support and Care Coordination ticket intake
- Partner onboarding for doctors, Panchakarma centres, labs and pharmacies
- Mock OTP login
- Patient dashboard with care plan, bookings and support tickets
- PWA manifest + service worker
- LocalStorage-backed prototype state

## Run locally
```bash
python3 -m http.server 8080
# Open http://localhost:8080
```
Or use any static web server.

## Production architecture alignment
The visual prototype maps to the approved ABIES stack:
- Frontend target: Next.js + React + TypeScript PWA
- Backend target: Node.js + NestJS + TypeScript
- Data: PostgreSQL + Redis + object storage
- Integrations: payment, logistics, WhatsApp/SMS/email, video, labs, ABDM-ready adapters
- Security: RBAC, consent, audit, MFA for privileged roles, WAF/rate-limits, encryption

## Next implementation sprints
1. Convert UI to Next.js design system and route modules
2. NestJS repo + auth/RBAC + PostgreSQL schema
3. Patient identity/profile + doctor onboarding and verification
4. Appointment, slot, payment and video adapters
5. Consultation notes, prescription and Care Plan Engine
6. Medicine order + pharmacy fulfilment + logistics
7. Support CRM + Customer 360 + Sales + TechOps queues
8. Admin configuration, refunds, audit and dashboards
9. Diagnostics partner workflow + reports
10. Panchakarma centre workflow + referrals + session tracking
11. Security hardening, observability, backups and UAT
12. Pilot go-live

Clinical note: AI/support functionality must never autonomously diagnose or change practitioner prescriptions.
