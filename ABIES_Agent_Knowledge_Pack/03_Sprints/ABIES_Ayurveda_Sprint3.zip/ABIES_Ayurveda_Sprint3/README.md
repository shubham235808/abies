# ABIES Ayurveda Care — Sprint 3

## Practitioner Onboarding, Verification & Discovery

Sprint 3 builds on the running Sprint 2 identity/RBAC stack and makes the practitioner network database-backed.

### Delivered

- Doctor self-onboarding with OTP (feature-flagged)
- Doctor professional profile
- Registration council/number and qualification capture
- Specialities, languages, consultation modes and fees
- Private credential-document upload (PDF/JPG/PNG)
- Clinic locations
- Recurring weekly availability
- Practitioner declaration + submission workflow
- Verification states: Draft → Submitted → Under Review → Approved / Rejected / Suspended
- MFA-protected admin review queue
- Admin credential verification
- Approval/rejection/suspension action history
- Public doctor discovery endpoint
- Search by query, city, speciality, language and consultation mode
- Public verified practitioner profile
- ABIES web frontend connected to the doctor APIs
- Audit baseline inherited from Sprint 2

### Important trust rule

A practitioner is returned by the public API only when:

```
verificationStatus = APPROVED
AND
isDiscoverable = true
```

Credential files are **not** exposed through public routes. Doctor-owned and admin-only download routes require an authenticated role-bound session.

### Runtime

```
Browser
  |
  v
Nginx :80
  |-------------------- static frontend
  |
  +---- /api/* -------> NestJS :3000
                            |
                            +---- PostgreSQL 16
                            |
                            +---- private upload volume
```

### Development accounts

- Patient: `9876543210`
- Doctor onboarding: `9876543211`
- Partner: `9876543212`
- Support: `9876543213`
- Admin: `9876543214`
- OTP: `123456`
- Admin MFA: `654321`

Six additional approved demo doctors are seeded for the public directory.

### Deployment

Read `DEPLOY_SPRINT3_UBUNTU.md` before upgrading the existing Sprint 2 VM. The guide preserves the current PostgreSQL Docker volume and includes a pre-upgrade database backup.

### Sprint boundary

The doctor directory is real and persistent in Sprint 3. Appointment inventory, booking transactions, payment and consultation lifecycle are intentionally left for Sprint 4.
