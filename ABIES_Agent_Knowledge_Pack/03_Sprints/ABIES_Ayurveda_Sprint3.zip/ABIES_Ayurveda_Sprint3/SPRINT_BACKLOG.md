# ABIES Ayurveda Care — Development Sprint Backlog

Cadence: 2 weeks per sprint. MVP pilot target: 24 weeks including hardening and go-live.

## Sprint 0 — Product & architecture runway
- Confirm product name/brand, pilot city, care policies and partner verification rules
- User stories for Patient, Doctor, Panchakarma Centre, Lab, Pharmacy, Support, Sales, TechOps, Admin
- Data model and API conventions
- Cloud environments, repository, CI/CD, secrets and coding standards
- Clinical safety and privacy review
**Exit:** approved backlog, architecture, data classification, environments and definition of done.

## Sprint 1 — Design system + public website + PWA shell
- ABIES design system, responsive layout, navigation and accessibility baseline
- Home, doctor discovery, Panchakarma, diagnostics, medicines, support, partner onboarding
- PWA manifest/offline shell
- Analytics event schema
**Exit:** responsive clickable website and component catalogue.

## Sprint 2 — Identity, patient profile & RBAC
- OTP login, sessions, patient/family profiles
- Doctor/partner/admin role framework
- Consent artefacts and audit-event baseline
- Admin MFA path
**Exit:** secure authentication and role gates in dev/staging.

## Sprint 3 — Doctor onboarding & discovery
- Practitioner onboarding, credential fields and verification workflow
- Doctor profiles, specialities, languages, city, consultation modes
- Availability and search filters
**Exit:** verified doctor can be approved by admin and discovered by patient.

## Sprint 4 — Appointments, payments & notifications
- Slot locking, booking, reschedule/cancel
- Razorpay/UPI adapter, idempotency and payment reconciliation
- Email/SMS/WhatsApp notification adapter
- Booking support timeline
**Exit:** paid consultation booking end-to-end in sandbox.

## Sprint 5 — Consultation, prescription & Care Plan Engine
- Video adapter
- Structured consultation notes
- Prescription versioning and practitioner signature path
- Care plan tasks, due dates and follow-up reminders
- Support/AI cannot alter clinical content
**Exit:** doctor can complete consultation and publish a traceable care plan.

## Sprint 6 — Medicines & pharmacy fulfilment
- Prescription medicine validation
- Pharmacy partner portal and order queue
- Inventory/availability fields, batch/expiry capture
- Logistics adapter and delivery events
- Refund/cancellation states
**Exit:** prescription-to-delivery workflow in staging.

## Sprint 7 — Customer Care, Sales & Technical Support CRM
- Customer 360 timeline
- Ticket queues: Customer Care, Sales, Technical Support, Care Coordination
- SLA timers, escalations, notes, refunds and resolution codes
- Partner sales pipeline and onboarding follow-ups
- Tech incident linking to booking/order
**Exit:** support teams can operate without external spreadsheets.

## Sprint 8 — Admin, finance & operational controls
- Master data, city/service/pricing configuration
- Partner activation/suspension
- Refund approvals, settlement views and audit logs
- Admin dashboards and access reviews
**Exit:** operations can administer the pilot without engineering intervention.

## Sprint 9 — Diagnostics workflow
- Test catalogue and lab partner portal
- Home collection slots, order and sample states
- Secure report upload and patient/doctor access
- Report-ready notifications and reconciliation
**Exit:** test booking-to-report workflow complete.

## Sprint 10 — Panchakarma partner workflow
- Centre onboarding and facility verification
- Therapy catalogue, doctor referral and suitability flags
- Session scheduling, attendance and notes
- Program progress back into Care Plan
**Exit:** doctor-referred therapy can be tracked session by session.

## Sprint 11 — Security, observability, backup & UAT
- WAF/rate limits, secrets, security headers, dependency/SAST checks
- OpenTelemetry, logs, metrics, business dashboards and alerting
- Backup/restore test, incident runbooks and release process
- Load/smoke/accessibility testing
- UAT and partner training
**Exit:** launch-readiness signoff.

## Sprint 12 — Pilot go-live & stabilisation
- Production deployment
- Hypercare command centre
- Booking/payment/delivery/support KPI dashboards
- Defect triage and release cadence
- Pilot learnings and next-city backlog
**Exit:** stable pilot with measurable care, operations and business KPIs.

## Phase 2 after pilot
- Native patient app (React Native/Flutter)
- ABDM/ABHA/FHIR integration path
- AI-assisted intake, note summarisation, translation and support triage
- Corporate wellness programs
- Advanced partner settlements and analytics
- Multi-city scale, autoscaling/Kubernetes/OpenShift where justified
