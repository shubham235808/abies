# ABIES Ayurveda — Sprint 3 Acceptance Test

## 1. Infrastructure

- PostgreSQL container healthy
- API container running
- `/api/v1/health` returns `sprint: 3`
- Nginx proxies `/api/` successfully

## 2. Public directory baseline

After seeding:

```bash
curl -s http://localhost/api/v1/public/doctors | jq '.total'
```

Expected: at least `6` demo practitioners.

Check facets:

```bash
curl -s http://localhost/api/v1/public/doctors/facets | jq
```

## 3. Doctor onboarding

Login in browser:

- Role: Doctor
- Mobile: `9876543211`
- OTP: `123456`

Complete:

1. First/last name
2. Registration council
3. Registration number
4. Qualification
5. Experience
6. At least one speciality
7. At least one language
8. Consultation mode + fee
9. Upload Registration Certificate
10. Upload Degree Certificate
11. Optional clinic
12. Weekly availability
13. Accept declaration and submit

Expected status: `SUBMITTED`.

## 4. Admin review

Login:

- Role: Admin
- Mobile: `9876543214`
- OTP: `123456`
- MFA: `654321`

Expected:

- Doctor appears in verification queue
- Admin can open application
- Credential files can be opened through authenticated admin route
- Registration and degree files can be marked Verified
- Admin can start review
- Admin can approve after required files are verified

Expected doctor status: `APPROVED` and `isDiscoverable=true`.

## 5. Public visibility

Logout and open `/doctors`.

Expected:

- Newly approved doctor appears in search
- Public detail page displays approved profile, clinics and availability
- Credential-file URLs are not exposed publicly

## 6. Rejection loop

Create a second doctor using a new Indian mobile number (Doctor self-onboarding is enabled in the development environment).

Submit application, then reject it from Admin with a reason.

Expected:

- Doctor sees `Changes required`
- Rejection reason is visible
- Profile can be edited again
- Editing moves application back to `DRAFT`
- Doctor can resubmit

## 7. Security tests

- Patient cannot call `/doctors/me`
- Doctor cannot call `/admin/doctors`
- Admin without MFA cannot call `/admin/doctors`
- Public caller cannot download credential documents
- Unsupported file types are rejected
- Files above configured upload size are rejected
- Suspended doctor disappears from public discovery
