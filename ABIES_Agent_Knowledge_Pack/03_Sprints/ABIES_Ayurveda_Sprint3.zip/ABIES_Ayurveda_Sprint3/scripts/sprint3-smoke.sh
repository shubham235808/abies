#!/usr/bin/env sh
set -eu
BASE="${BASE_URL:-http://localhost/api/v1}"
echo "[1/4] health"
curl -fsS "$BASE/health" | grep '"sprint":3' >/dev/null || curl -fsS "$BASE/health"
echo "OK"
echo "[2/4] public doctors"
COUNT=$(curl -fsS "$BASE/public/doctors" | sed -n 's/.*"total":\([0-9][0-9]*\).*/\1/p' | head -1)
echo "total=$COUNT"
echo "[3/4] facets"
curl -fsS "$BASE/public/doctors/facets" >/dev/null
echo "OK"
echo "[4/4] credential route is not public"
CODE=$(curl -s -o /dev/null -w '%{http_code}' "$BASE/doctors/me/documents")
[ "$CODE" = "401" ] || { echo "Expected 401, got $CODE"; exit 1; }
echo "OK"
echo "Sprint 3 public smoke test passed."
