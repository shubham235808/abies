import { Controller, Get, UseGuards } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { CurrentUser } from './common/decorators/current-user.decorator';
import { Roles } from './common/decorators/roles.decorator';
import { JwtAuthGuard } from './common/guards/jwt-auth.guard';
import { MfaGuard } from './common/guards/mfa.guard';
import { RolesGuard } from './common/guards/roles.guard';

@Controller('access')
@UseGuards(JwtAuthGuard, RolesGuard, MfaGuard)
export class AccessController {
  @Get('doctor') @Roles(UserRole.DOCTOR, UserRole.ADMIN) doctor(@CurrentUser() user: any) { return { ok: true, gate: 'doctor', user }; }
  @Get('partner') @Roles(UserRole.PARTNER, UserRole.ADMIN) partner(@CurrentUser() user: any) { return { ok: true, gate: 'partner', user }; }
  @Get('support') @Roles(UserRole.SUPPORT, UserRole.ADMIN) support(@CurrentUser() user: any) { return { ok: true, gate: 'support', user }; }
  @Get('admin') @Roles(UserRole.ADMIN) admin(@CurrentUser() user: any) { return { ok: true, gate: 'admin+mfa', user }; }
}
