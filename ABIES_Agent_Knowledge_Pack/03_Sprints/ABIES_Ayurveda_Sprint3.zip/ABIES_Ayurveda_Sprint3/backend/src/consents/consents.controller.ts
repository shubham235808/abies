import { Controller, Get, UseGuards } from '@nestjs/common';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { PrismaService } from '../prisma.service';

@Controller('consents')
export class ConsentsController {
  constructor(private prisma: PrismaService) {}

  @Get('current')
  async current() {
    return this.prisma.consentArtifact.findMany({ where: { active: true }, orderBy: [{ key: 'asc' }, { version: 'desc' }] });
  }

  @UseGuards(JwtAuthGuard)
  @Get('me')
  async mine(@CurrentUser() user: any) {
    return this.prisma.consentRecord.findMany({ where: { userId: user.id }, include: { artifact: true }, orderBy: { acceptedAt: 'desc' } });
  }
}
