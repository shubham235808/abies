import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { ConsentsController } from './consents.controller';
import { PrismaService } from '../prisma.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
@Module({ imports: [JwtModule.register({})], controllers: [ConsentsController], providers: [PrismaService, JwtAuthGuard] })
export class ConsentsModule {}
