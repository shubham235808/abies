import { Body, Controller, Get, Param, Post, Query, Res, UseGuards } from '@nestjs/common';
import { DoctorVerificationStatus, UserRole } from '@prisma/client';
import { Response } from 'express';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import { Roles } from '../common/decorators/roles.decorator';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { MfaGuard } from '../common/guards/mfa.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { AdminDoctorsService } from './admin-doctors.service';
import { DoctorsService } from './doctors.service';
import { RejectDoctorDto, ReviewDoctorDto, ReviewDocumentDto } from './doctors.dto';

@Controller('admin/doctors')
@UseGuards(JwtAuthGuard, RolesGuard, MfaGuard)
@Roles(UserRole.ADMIN)
export class AdminDoctorsController {
  constructor(private admin: AdminDoctorsService, private doctors: DoctorsService) {}

  @Get()
  queue(@Query('status') rawStatus?: string) {
    const status = rawStatus && Object.values(DoctorVerificationStatus).includes(rawStatus as DoctorVerificationStatus) ? rawStatus as DoctorVerificationStatus : undefined;
    return this.admin.queue(status);
  }

  @Get(':id')
  detail(@Param('id') id: string) { return this.admin.detail(id); }

  @Post(':id/start-review')
  startReview(@CurrentUser() user: any, @Param('id') id: string, @Body() dto: ReviewDoctorDto) { return this.admin.startReview(id, user.id, dto.notes); }

  @Post(':id/approve')
  approve(@CurrentUser() user: any, @Param('id') id: string, @Body() dto: ReviewDoctorDto) { return this.admin.approve(id, user.id, dto.notes); }

  @Post(':id/reject')
  reject(@CurrentUser() user: any, @Param('id') id: string, @Body() dto: RejectDoctorDto) { return this.admin.reject(id, user.id, dto.reason); }

  @Post(':id/suspend')
  suspend(@CurrentUser() user: any, @Param('id') id: string, @Body() dto: RejectDoctorDto) { return this.admin.suspend(id, user.id, dto.reason); }

  @Post(':id/documents/:documentId/review')
  reviewDocument(@CurrentUser() user: any, @Param('id') id: string, @Param('documentId') documentId: string, @Body() dto: ReviewDocumentDto) {
    return this.admin.reviewDocument(id, documentId, user.id, dto.verified, dto.note);
  }

  @Get(':id/documents/:documentId/download')
  async downloadDocument(@Param('id') id: string, @Param('documentId') documentId: string, @Res() res: Response) {
    const document = await this.admin.document(id, documentId);
    return res.download(this.doctors.safeFilePath(document.storagePath), document.originalName);
  }
}
