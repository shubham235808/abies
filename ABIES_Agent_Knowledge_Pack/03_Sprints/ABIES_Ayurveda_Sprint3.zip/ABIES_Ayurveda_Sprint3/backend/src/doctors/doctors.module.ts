import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PrismaService } from '../prisma.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { MfaGuard } from '../common/guards/mfa.guard';
import { DoctorsController, PublicDoctorsController } from './doctors.controller';
import { AdminDoctorsController } from './admin-doctors.controller';
import { DoctorsService } from './doctors.service';
import { AdminDoctorsService } from './admin-doctors.service';

@Module({
  imports: [JwtModule.register({})],
  controllers: [DoctorsController, PublicDoctorsController, AdminDoctorsController],
  providers: [PrismaService, JwtAuthGuard, RolesGuard, MfaGuard, DoctorsService, AdminDoctorsService],
})
export class DoctorsModule {}
