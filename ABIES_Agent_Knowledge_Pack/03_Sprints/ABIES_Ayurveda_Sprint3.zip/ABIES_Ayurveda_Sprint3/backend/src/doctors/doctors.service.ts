import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ConsultationMode, DoctorDocumentStatus, DoctorDocumentType, DoctorVerificationStatus, Prisma } from '@prisma/client';
import { promises as fs } from 'fs';
import { basename, join } from 'path';
import { PrismaService } from '../prisma.service';
import { CreateAvailabilityDto, CreateClinicDto, UpdateAvailabilityDto, UpdateClinicDto, UpdateDoctorProfileDto } from './doctors.dto';

@Injectable()
export class DoctorsService {
  constructor(private prisma: PrismaService, private config: ConfigService) {}

  private slugPart(value?: string | null) {
    return String(value || '')
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .slice(0, 48);
  }

  private async uniqueSlug(firstName?: string | null, lastName?: string | null, userId?: string) {
    const base = [this.slugPart(firstName), this.slugPart(lastName)].filter(Boolean).join('-') || `doctor-${String(userId || '').slice(-6)}`;
    let slug = base;
    let n = 2;
    while (await this.prisma.doctorProfile.findUnique({ where: { slug } })) slug = `${base}-${n++}`;
    return slug;
  }

  async ensureProfile(userId: string): Promise<any> {
    const existing = await this.prisma.doctorProfile.findUnique({ where: { userId }, include: this.privateInclude() });
    if (existing) return existing;
    return this.prisma.doctorProfile.create({
      data: { userId, slug: await this.uniqueSlug(undefined, undefined, userId) },
      include: this.privateInclude(),
    });
  }

  private privateInclude(): any {
    return {
      documents: { orderBy: { createdAt: 'desc' as const } },
      clinics: { orderBy: { createdAt: 'asc' as const } },
      availability: { orderBy: [{ dayOfWeek: 'asc' as const }, { startTime: 'asc' as const }] },
      verificationActions: { orderBy: { createdAt: 'desc' as const }, take: 20 },
      user: { select: { mobile: true, email: true, status: true } },
    };
  }

  async getMe(userId: string) {
    const profile = await this.ensureProfile(userId);
    return { profile, completion: this.completion(profile) };
  }

  private editableStatus(status: DoctorVerificationStatus) {
    return status === DoctorVerificationStatus.DRAFT || status === DoctorVerificationStatus.REJECTED;
  }

  private async profileForOwner(userId: string) {
    return this.ensureProfile(userId);
  }

  async updateMe(userId: string, dto: UpdateDoctorProfileDto) {
    const profile = await this.profileForOwner(userId);
    if (!this.editableStatus(profile.verificationStatus)) {
      throw new ForbiddenException('Profile details are locked while verification is in progress or approved. Contact support for regulated profile changes.');
    }
    const data: Prisma.DoctorProfileUpdateInput = { ...dto };
    if ((dto.firstName !== undefined || dto.lastName !== undefined) && profile.slug.startsWith('doctor-')) {
      data.slug = await this.uniqueSlug(dto.firstName ?? profile.firstName, dto.lastName ?? profile.lastName, userId);
    }
    if (profile.verificationStatus === DoctorVerificationStatus.REJECTED) {
      data.verificationStatus = DoctorVerificationStatus.DRAFT;
      data.rejectionReason = null;
      data.reviewedAt = null;
      data.reviewedByUserId = null;
    }
    try {
      const updated = await this.prisma.doctorProfile.update({ where: { id: profile.id }, data, include: this.privateInclude() });
      return { profile: updated, completion: this.completion(updated) };
    } catch (error: any) {
      if (error?.code === 'P2002') throw new BadRequestException('This practitioner registration is already associated with another ABIES account');
      throw error;
    }
  }

  async addDocument(userId: string, type: DoctorDocumentType, file: any) {
    const profile = await this.profileForOwner(userId);
    if (!this.editableStatus(profile.verificationStatus)) throw new ForbiddenException('Documents can be changed only while the application is in Draft or Rejected state');
    if (!file) throw new BadRequestException('Document file is required');
    const allowed = new Set(['application/pdf', 'image/jpeg', 'image/png']);
    if (!allowed.has(file.mimetype)) {
      await fs.unlink(file.path).catch(() => undefined);
      throw new BadRequestException('Only PDF, JPG and PNG documents are accepted');
    }
    const document = await this.prisma.doctorDocument.create({
      data: {
        doctorProfileId: profile.id,
        type,
        originalName: file.originalname,
        storedName: file.filename,
        mimeType: file.mimetype,
        sizeBytes: file.size,
        storagePath: file.path,
      },
    });
    return { document };
  }

  async listDocuments(userId: string) {
    const profile = await this.profileForOwner(userId);
    return this.prisma.doctorDocument.findMany({ where: { doctorProfileId: profile.id }, orderBy: { createdAt: 'desc' } });
  }

  async documentForOwner(userId: string, id: string) {
    const profile = await this.profileForOwner(userId);
    const document = await this.prisma.doctorDocument.findFirst({ where: { id, doctorProfileId: profile.id } });
    if (!document) throw new NotFoundException('Document not found');
    return document;
  }

  async removeDocument(userId: string, id: string) {
    const profile = await this.profileForOwner(userId);
    if (!this.editableStatus(profile.verificationStatus)) throw new ForbiddenException('Documents cannot be removed while verification is in progress or approved');
    const document = await this.documentForOwner(userId, id);
    await this.prisma.doctorDocument.delete({ where: { id } });
    await fs.unlink(document.storagePath).catch(() => undefined);
    return { ok: true };
  }

  async addClinic(userId: string, dto: CreateClinicDto) {
    const profile = await this.profileForOwner(userId);
    return this.prisma.doctorClinic.create({ data: { doctorProfileId: profile.id, ...dto } });
  }

  async updateClinic(userId: string, id: string, dto: UpdateClinicDto) {
    const profile = await this.profileForOwner(userId);
    const clinic = await this.prisma.doctorClinic.findFirst({ where: { id, doctorProfileId: profile.id } });
    if (!clinic) throw new NotFoundException('Clinic not found');
    return this.prisma.doctorClinic.update({ where: { id }, data: dto });
  }

  async removeClinic(userId: string, id: string) {
    const profile = await this.profileForOwner(userId);
    const result = await this.prisma.doctorClinic.deleteMany({ where: { id, doctorProfileId: profile.id } });
    if (!result.count) throw new NotFoundException('Clinic not found');
    return { ok: true };
  }

  async addAvailability(userId: string, dto: CreateAvailabilityDto) {
    if (dto.startTime >= dto.endTime) throw new BadRequestException('End time must be after start time');
    const profile = await this.profileForOwner(userId);
    if (!profile.consultationModes.includes(dto.mode)) throw new BadRequestException(`Enable ${dto.mode} consultation mode on your profile first`);
    return this.prisma.doctorAvailability.create({ data: { doctorProfileId: profile.id, ...dto } });
  }

  async updateAvailability(userId: string, id: string, dto: UpdateAvailabilityDto) {
    const profile = await this.profileForOwner(userId);
    const slot = await this.prisma.doctorAvailability.findFirst({ where: { id, doctorProfileId: profile.id } });
    if (!slot) throw new NotFoundException('Availability slot not found');
    const start = dto.startTime ?? slot.startTime;
    const end = dto.endTime ?? slot.endTime;
    if (start >= end) throw new BadRequestException('End time must be after start time');
    if (dto.mode && !profile.consultationModes.includes(dto.mode)) throw new BadRequestException(`Enable ${dto.mode} consultation mode on your profile first`);
    return this.prisma.doctorAvailability.update({ where: { id }, data: dto });
  }

  async removeAvailability(userId: string, id: string) {
    const profile = await this.profileForOwner(userId);
    const result = await this.prisma.doctorAvailability.deleteMany({ where: { id, doctorProfileId: profile.id } });
    if (!result.count) throw new NotFoundException('Availability slot not found');
    return { ok: true };
  }

  async submit(userId: string, declarationAccepted: boolean) {
    if (!declarationAccepted) throw new BadRequestException('The practitioner declaration must be accepted');
    const profile = await this.profileForOwner(userId);
    if (!this.editableStatus(profile.verificationStatus)) throw new BadRequestException('Application is not in a submittable state');

    const missing: string[] = [];
    if (!profile.firstName) missing.push('first name');
    if (!profile.lastName) missing.push('last name');
    if (!profile.registrationCouncil) missing.push('registration council');
    if (!profile.registrationNumber) missing.push('registration number');
    if (!profile.primaryQualification) missing.push('primary qualification');
    if (profile.yearsExperience === null || profile.yearsExperience === undefined) missing.push('years of experience');
    if (!profile.specialties.length) missing.push('at least one speciality');
    if (!profile.languages.length) missing.push('at least one language');
    if (!profile.consultationModes.length) missing.push('consultation mode');
    if (profile.consultationModes.includes(ConsultationMode.VIDEO) && profile.videoFee === null) missing.push('video consultation fee');
    if (profile.consultationModes.includes(ConsultationMode.CLINIC) && profile.clinicFee === null) missing.push('clinic consultation fee');

    const documents = await this.prisma.doctorDocument.findMany({ where: { doctorProfileId: profile.id } });
    if (!documents.some(d => d.type === DoctorDocumentType.REGISTRATION_CERTIFICATE)) missing.push('registration certificate');
    if (!documents.some(d => d.type === DoctorDocumentType.DEGREE_CERTIFICATE)) missing.push('degree certificate');
    if (missing.length) throw new BadRequestException(`Complete the application before submission: ${missing.join(', ')}`);

    const updated = await this.prisma.doctorProfile.update({
      where: { id: profile.id },
      data: { verificationStatus: DoctorVerificationStatus.SUBMITTED, submittedAt: new Date(), rejectionReason: null, isDiscoverable: false },
      include: this.privateInclude(),
    });
    return { profile: updated, message: 'Application submitted for ABIES verification' };
  }

  async searchPublic(query: Record<string, any>) {
    const take = Math.min(Math.max(Number(query.limit || 24), 1), 50);
    const skip = Math.max(Number(query.offset || 0), 0);
    const where: Prisma.DoctorProfileWhereInput = {
      verificationStatus: DoctorVerificationStatus.APPROVED,
      isDiscoverable: true,
      isAcceptingNewPatients: query.accepting === 'false' ? undefined : true,
    };
    if (query.city) where.clinics = { some: { active: true, city: { contains: String(query.city), mode: 'insensitive' } } };
    if (query.language) where.languages = { has: String(query.language) };
    if (query.specialty) where.specialties = { has: String(query.specialty) };
    if (query.mode && Object.values(ConsultationMode).includes(String(query.mode) as ConsultationMode)) where.consultationModes = { has: String(query.mode) as ConsultationMode };
    if (query.q) {
      const q = String(query.q).trim();
      where.OR = [
        { firstName: { contains: q, mode: 'insensitive' } },
        { lastName: { contains: q, mode: 'insensitive' } },
        { primaryQualification: { contains: q, mode: 'insensitive' } },
        { highestQualification: { contains: q, mode: 'insensitive' } },
        { bio: { contains: q, mode: 'insensitive' } },
      ];
    }
    const [total, rows] = await this.prisma.$transaction([
      this.prisma.doctorProfile.count({ where }),
      this.prisma.doctorProfile.findMany({
        where, skip, take,
        orderBy: [{ rating: 'desc' }, { yearsExperience: 'desc' }, { createdAt: 'asc' }],
        include: { clinics: { where: { active: true }, orderBy: { createdAt: 'asc' } }, availability: { where: { active: true }, orderBy: [{ dayOfWeek: 'asc' }, { startTime: 'asc' }] } },
      }),
    ]);
    return { total, offset: skip, limit: take, doctors: rows.map(d => this.publicDoctor(d)) };
  }

  async publicProfile(slug: string) {
    const doctor = await this.prisma.doctorProfile.findFirst({
      where: { slug, verificationStatus: DoctorVerificationStatus.APPROVED, isDiscoverable: true },
      include: { clinics: { where: { active: true }, orderBy: { createdAt: 'asc' } }, availability: { where: { active: true }, orderBy: [{ dayOfWeek: 'asc' }, { startTime: 'asc' }] } },
    });
    if (!doctor) throw new NotFoundException('Doctor not found');
    return { doctor: this.publicDoctor(doctor) };
  }

  async facets() {
    const doctors = await this.prisma.doctorProfile.findMany({
      where: { verificationStatus: DoctorVerificationStatus.APPROVED, isDiscoverable: true },
      select: { specialties: true, languages: true, clinics: { where: { active: true }, select: { city: true } } },
    });
    const uniq = (xs: string[]) => [...new Set(xs.filter(Boolean))].sort((a, b) => a.localeCompare(b));
    return {
      specialties: uniq(doctors.flatMap(d => d.specialties)),
      languages: uniq(doctors.flatMap(d => d.languages)),
      cities: uniq(doctors.flatMap(d => d.clinics.map(c => c.city))),
    };
  }

  publicDoctor(d: any) {
    const fullName = [d.title || 'Dr.', d.firstName, d.lastName].filter(Boolean).join(' ');
    const modes = (d.consultationModes || []) as ConsultationMode[];
    const fees = [modes.includes(ConsultationMode.VIDEO) ? d.videoFee : null, modes.includes(ConsultationMode.CLINIC) ? d.clinicFee : null].filter((x: any) => x !== null && x !== undefined);
    return {
      id: d.id,
      slug: d.slug,
      name: fullName,
      firstName: d.firstName,
      lastName: d.lastName,
      bio: d.bio,
      registrationCouncil: d.registrationCouncil,
      registrationNumber: d.registrationNumber,
      primaryQualification: d.primaryQualification,
      highestQualification: d.highestQualification,
      yearsExperience: d.yearsExperience,
      specialties: d.specialties,
      languages: d.languages,
      consultationModes: d.consultationModes,
      videoFee: d.videoFee,
      clinicFee: d.clinicFee,
      startingFee: fees.length ? Math.min(...(fees as number[])) : null,
      rating: d.rating,
      reviewCount: d.reviewCount,
      clinics: d.clinics || [],
      availability: d.availability || [],
      verified: true,
      acceptingNewPatients: d.isAcceptingNewPatients,
    };
  }

  completion(profile: any) {
    const fields = [
      profile.firstName, profile.lastName, profile.registrationCouncil, profile.registrationNumber,
      profile.primaryQualification, profile.yearsExperience !== null && profile.yearsExperience !== undefined,
      profile.specialties?.length, profile.languages?.length, profile.consultationModes?.length,
      profile.bio,
    ];
    const base = fields.filter(Boolean).length;
    const docs = profile.documents || [];
    const requiredDocs = [DoctorDocumentType.REGISTRATION_CERTIFICATE, DoctorDocumentType.DEGREE_CERTIFICATE]
      .filter(t => docs.some((d: any) => d.type === t)).length;
    return Math.round(((base + requiredDocs) / 12) * 100);
  }

  uploadDir() { return this.config.get<string>('UPLOAD_DIR') || '/app/uploads'; }
  safeFilePath(storagePath: string) {
    const root = this.uploadDir();
    const file = basename(storagePath);
    return join(root, file);
  }
}
