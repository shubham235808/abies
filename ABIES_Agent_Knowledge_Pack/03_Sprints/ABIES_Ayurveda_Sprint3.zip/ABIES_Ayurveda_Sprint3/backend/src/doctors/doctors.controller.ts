import { BadRequestException, Body, Controller, Delete, Get, Param, Patch, Post, Query, Res, UploadedFile, UseGuards, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { DoctorDocumentType, UserRole } from '@prisma/client';
import { diskStorage } from 'multer';
import { mkdirSync } from 'fs';
import { extname } from 'path';
import { randomUUID } from 'crypto';
import { Response } from 'express';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import { Roles } from '../common/decorators/roles.decorator';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { CreateAvailabilityDto, CreateClinicDto, SubmitDoctorProfileDto, UpdateAvailabilityDto, UpdateClinicDto, UpdateDoctorProfileDto } from './doctors.dto';
import { DoctorsService } from './doctors.service';

const uploadStorage = diskStorage({
  destination: (_req, _file, cb) => {
    const dir = process.env.UPLOAD_DIR || '/app/uploads';
    mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (_req, file, cb) => cb(null, `${Date.now()}-${randomUUID()}${extname(file.originalname).toLowerCase()}`),
});

@Controller('doctors')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(UserRole.DOCTOR)
export class DoctorsController {
  constructor(private doctors: DoctorsService) {}

  @Get('me')
  me(@CurrentUser() user: any) { return this.doctors.getMe(user.id); }

  @Patch('me')
  updateMe(@CurrentUser() user: any, @Body() dto: UpdateDoctorProfileDto) { return this.doctors.updateMe(user.id, dto); }

  @Post('me/submit')
  submit(@CurrentUser() user: any, @Body() dto: SubmitDoctorProfileDto) { return this.doctors.submit(user.id, dto.declarationAccepted); }

  @Get('me/documents')
  documents(@CurrentUser() user: any) { return this.doctors.listDocuments(user.id); }

  @Post('me/documents')
  @UseInterceptors(FileInterceptor('file', { storage: uploadStorage, limits: { fileSize: Number(process.env.MAX_UPLOAD_MB || 8) * 1024 * 1024 } }))
  uploadDocument(@CurrentUser() user: any, @Body('type') rawType: string, @UploadedFile() file: any) {
    if (!Object.values(DoctorDocumentType).includes(rawType as DoctorDocumentType)) throw new BadRequestException('Invalid document type');
    return this.doctors.addDocument(user.id, rawType as DoctorDocumentType, file);
  }

  @Get('me/documents/:id/download')
  async downloadDocument(@CurrentUser() user: any, @Param('id') id: string, @Res() res: Response) {
    const document = await this.doctors.documentForOwner(user.id, id);
    return res.download(this.doctors.safeFilePath(document.storagePath), document.originalName);
  }

  @Delete('me/documents/:id')
  removeDocument(@CurrentUser() user: any, @Param('id') id: string) { return this.doctors.removeDocument(user.id, id); }

  @Post('me/clinics')
  addClinic(@CurrentUser() user: any, @Body() dto: CreateClinicDto) { return this.doctors.addClinic(user.id, dto); }

  @Patch('me/clinics/:id')
  updateClinic(@CurrentUser() user: any, @Param('id') id: string, @Body() dto: UpdateClinicDto) { return this.doctors.updateClinic(user.id, id, dto); }

  @Delete('me/clinics/:id')
  removeClinic(@CurrentUser() user: any, @Param('id') id: string) { return this.doctors.removeClinic(user.id, id); }

  @Post('me/availability')
  addAvailability(@CurrentUser() user: any, @Body() dto: CreateAvailabilityDto) { return this.doctors.addAvailability(user.id, dto); }

  @Patch('me/availability/:id')
  updateAvailability(@CurrentUser() user: any, @Param('id') id: string, @Body() dto: UpdateAvailabilityDto) { return this.doctors.updateAvailability(user.id, id, dto); }

  @Delete('me/availability/:id')
  removeAvailability(@CurrentUser() user: any, @Param('id') id: string) { return this.doctors.removeAvailability(user.id, id); }
}

@Controller('public/doctors')
export class PublicDoctorsController {
  constructor(private doctors: DoctorsService) {}

  @Get()
  search(@Query() query: Record<string, string>) { return this.doctors.searchPublic(query); }

  @Get('facets')
  facets() { return this.doctors.facets(); }

  @Get(':slug')
  profile(@Param('slug') slug: string) { return this.doctors.publicProfile(slug); }
}
