import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { DoctorDocumentStatus, DoctorVerificationStatus } from '@prisma/client';
import { PrismaService } from '../prisma.service';

@Injectable()
export class AdminDoctorsService {
  constructor(private prisma: PrismaService) {}

  private includeFull(): any {
    return {
      user: { select: { id: true, mobile: true, email: true, status: true, createdAt: true } },
      documents: { orderBy: { createdAt: 'desc' as const } },
      clinics: { orderBy: { createdAt: 'asc' as const } },
      availability: { orderBy: [{ dayOfWeek: 'asc' as const }, { startTime: 'asc' as const }] },
      verificationActions: { orderBy: { createdAt: 'desc' as const }, take: 50 },
    };
  }

  async queue(status?: DoctorVerificationStatus) {
    const where: any = status ? { verificationStatus: status } : { verificationStatus: { in: [DoctorVerificationStatus.SUBMITTED, DoctorVerificationStatus.UNDER_REVIEW] } };
    const doctors = await this.prisma.doctorProfile.findMany({
      where,
      include: { user: { select: { mobile: true, email: true } }, documents: true, clinics: true },
      orderBy: [{ submittedAt: 'asc' }, { createdAt: 'asc' }],
    });
    return { total: doctors.length, doctors: doctors.map(d => ({
      id: d.id,
      slug: d.slug,
      name: [d.title, d.firstName, d.lastName].filter(Boolean).join(' '),
      mobile: d.user.mobile,
      email: d.user.email,
      qualification: d.highestQualification || d.primaryQualification,
      registrationCouncil: d.registrationCouncil,
      registrationNumber: d.registrationNumber,
      specialties: d.specialties,
      verificationStatus: d.verificationStatus,
      submittedAt: d.submittedAt,
      documentCount: d.documents.length,
      clinicCount: d.clinics.length,
      rejectionReason: d.rejectionReason,
    })) };
  }

  async detail(id: string) {
    const doctor = await this.prisma.doctorProfile.findUnique({ where: { id }, include: this.includeFull() });
    if (!doctor) throw new NotFoundException('Doctor application not found');
    return { doctor };
  }

  private async transition(id: string, adminUserId: string, toStatus: DoctorVerificationStatus, notes?: string, extra: any = {}) {
    const doctor = await this.prisma.doctorProfile.findUnique({ where: { id } });
    if (!doctor) throw new NotFoundException('Doctor application not found');
    const updated = await this.prisma.$transaction(async tx => {
      const profile = await tx.doctorProfile.update({
        where: { id },
        data: {
          verificationStatus: toStatus,
          reviewedAt: (toStatus === DoctorVerificationStatus.APPROVED || toStatus === DoctorVerificationStatus.REJECTED || toStatus === DoctorVerificationStatus.SUSPENDED) ? new Date() : doctor.reviewedAt,
          reviewedByUserId: adminUserId,
          ...extra,
        },
      });
      await tx.doctorVerificationAction.create({ data: { doctorProfileId: id, adminUserId, fromStatus: doctor.verificationStatus, toStatus, notes } });
      return profile;
    });
    return { doctor: updated };
  }

  async startReview(id: string, adminUserId: string, notes?: string) {
    const doctor = await this.prisma.doctorProfile.findUnique({ where: { id } });
    if (!doctor) throw new NotFoundException('Doctor application not found');
    if (doctor.verificationStatus !== DoctorVerificationStatus.SUBMITTED) throw new BadRequestException('Only submitted applications can enter review');
    return this.transition(id, adminUserId, DoctorVerificationStatus.UNDER_REVIEW, notes, { isDiscoverable: false });
  }

  async approve(id: string, adminUserId: string, notes?: string) {
    const doctor = await this.prisma.doctorProfile.findUnique({ where: { id }, include: { documents: true } });
    if (!doctor) throw new NotFoundException('Doctor application not found');
    if (doctor.verificationStatus !== DoctorVerificationStatus.SUBMITTED && doctor.verificationStatus !== DoctorVerificationStatus.UNDER_REVIEW) throw new BadRequestException('Application is not ready for approval');
    const reg = doctor.documents.find(d => d.type === 'REGISTRATION_CERTIFICATE');
    const degree = doctor.documents.find(d => d.type === 'DEGREE_CERTIFICATE');
    if (!reg || !degree) throw new BadRequestException('Registration and degree documents are required');
    if (reg.status !== DoctorDocumentStatus.VERIFIED || degree.status !== DoctorDocumentStatus.VERIFIED) {
      throw new BadRequestException('Registration and degree documents must be verified before approval');
    }
    return this.transition(id, adminUserId, DoctorVerificationStatus.APPROVED, notes, {
      isDiscoverable: true,
      rejectionReason: null,
      reviewedAt: new Date(),
    });
  }

  async reject(id: string, adminUserId: string, reason: string) {
    const doctor = await this.prisma.doctorProfile.findUnique({ where: { id } });
    if (!doctor) throw new NotFoundException('Doctor application not found');
    if (doctor.verificationStatus !== DoctorVerificationStatus.SUBMITTED && doctor.verificationStatus !== DoctorVerificationStatus.UNDER_REVIEW) throw new BadRequestException('Application is not in review');
    return this.transition(id, adminUserId, DoctorVerificationStatus.REJECTED, reason, {
      isDiscoverable: false,
      rejectionReason: reason,
      reviewedAt: new Date(),
    });
  }

  async suspend(id: string, adminUserId: string, reason: string) {
    const doctor = await this.prisma.doctorProfile.findUnique({ where: { id } });
    if (!doctor) throw new NotFoundException('Doctor application not found');
    if (doctor.verificationStatus !== DoctorVerificationStatus.APPROVED) throw new BadRequestException('Only approved doctors can be suspended');
    return this.transition(id, adminUserId, DoctorVerificationStatus.SUSPENDED, reason, {
      isDiscoverable: false,
      rejectionReason: reason,
      reviewedAt: new Date(),
    });
  }

  async reviewDocument(doctorId: string, documentId: string, adminUserId: string, verified: boolean, note?: string) {
    const document = await this.prisma.doctorDocument.findFirst({ where: { id: documentId, doctorProfileId: doctorId } });
    if (!document) throw new NotFoundException('Document not found');
    const updated = await this.prisma.doctorDocument.update({
      where: { id: documentId },
      data: { status: verified ? DoctorDocumentStatus.VERIFIED : DoctorDocumentStatus.REJECTED, reviewNote: note, verifiedAt: verified ? new Date() : null },
    });
    await this.prisma.auditEvent.create({ data: {
      userId: adminUserId,
      eventType: 'DOCTOR_DOCUMENT_REVIEW',
      resourceType: 'DoctorDocument',
      resourceId: documentId,
      action: verified ? 'VERIFY' : 'REJECT',
      metadata: { doctorId, note },
    }});
    return { document: updated };
  }

  async document(id: string, documentId: string) {
    const document = await this.prisma.doctorDocument.findFirst({ where: { id: documentId, doctorProfileId: id } });
    if (!document) throw new NotFoundException('Document not found');
    return document;
  }
}
