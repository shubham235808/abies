import { ConsultationMode, DoctorDocumentType, DoctorVerificationStatus } from '@prisma/client';
import { ArrayMaxSize, IsArray, IsBoolean, IsEnum, IsInt, IsNotEmpty, IsNumber, IsOptional, IsString, Matches, Max, MaxLength, Min, MinLength } from 'class-validator';
import { Type } from 'class-transformer';

export class UpdateDoctorProfileDto {
  @IsOptional() @IsString() @MaxLength(20) title?: string;
  @IsOptional() @IsString() @MaxLength(80) firstName?: string;
  @IsOptional() @IsString() @MaxLength(80) lastName?: string;
  @IsOptional() @IsString() @MaxLength(40) gender?: string;
  @IsOptional() @IsString() @MaxLength(3000) bio?: string;
  @IsOptional() @IsString() @MaxLength(160) registrationCouncil?: string;
  @IsOptional() @IsString() @MaxLength(120) registrationNumber?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1950) @Max(2100) registrationYear?: number;
  @IsOptional() @IsString() @MaxLength(180) primaryQualification?: string;
  @IsOptional() @IsString() @MaxLength(180) highestQualification?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(0) @Max(70) yearsExperience?: number;
  @IsOptional() @IsArray() @ArrayMaxSize(12) @IsString({ each: true }) specialties?: string[];
  @IsOptional() @IsArray() @ArrayMaxSize(12) @IsString({ each: true }) languages?: string[];
  @IsOptional() @IsArray() @ArrayMaxSize(2) @IsEnum(ConsultationMode, { each: true }) consultationModes?: ConsultationMode[];
  @IsOptional() @Type(() => Number) @IsInt() @Min(0) @Max(100000) videoFee?: number;
  @IsOptional() @Type(() => Number) @IsInt() @Min(0) @Max(100000) clinicFee?: number;
  @IsOptional() @IsBoolean() isAcceptingNewPatients?: boolean;
}

export class CreateClinicDto {
  @IsString() @MinLength(2) @MaxLength(160) name!: string;
  @IsString() @MinLength(3) @MaxLength(220) addressLine1!: string;
  @IsOptional() @IsString() @MaxLength(220) addressLine2?: string;
  @IsString() @MinLength(2) @MaxLength(100) city!: string;
  @IsString() @MinLength(2) @MaxLength(100) state!: string;
  @IsString() @Matches(/^\d{6}$/) postalCode!: string;
  @IsOptional() @IsString() @MaxLength(30) phone?: string;
  @IsOptional() @Type(() => Number) @IsNumber() @Min(-90) @Max(90) latitude?: number;
  @IsOptional() @Type(() => Number) @IsNumber() @Min(-180) @Max(180) longitude?: number;
}

export class UpdateClinicDto {
  @IsOptional() @IsString() @MinLength(2) @MaxLength(160) name?: string;
  @IsOptional() @IsString() @MinLength(3) @MaxLength(220) addressLine1?: string;
  @IsOptional() @IsString() @MaxLength(220) addressLine2?: string;
  @IsOptional() @IsString() @MinLength(2) @MaxLength(100) city?: string;
  @IsOptional() @IsString() @MinLength(2) @MaxLength(100) state?: string;
  @IsOptional() @IsString() @Matches(/^\d{6}$/) postalCode?: string;
  @IsOptional() @IsString() @MaxLength(30) phone?: string;
  @IsOptional() @Type(() => Number) @IsNumber() @Min(-90) @Max(90) latitude?: number;
  @IsOptional() @Type(() => Number) @IsNumber() @Min(-180) @Max(180) longitude?: number;
  @IsOptional() @IsBoolean() active?: boolean;
}

export class CreateAvailabilityDto {
  @Type(() => Number) @IsInt() @Min(0) @Max(6) dayOfWeek!: number;
  @IsString() @Matches(/^([01]\d|2[0-3]):[0-5]\d$/) startTime!: string;
  @IsString() @Matches(/^([01]\d|2[0-3]):[0-5]\d$/) endTime!: string;
  @Type(() => Number) @IsInt() @Min(10) @Max(180) slotMinutes!: number;
  @IsEnum(ConsultationMode) mode!: ConsultationMode;
}

export class UpdateAvailabilityDto {
  @IsOptional() @Type(() => Number) @IsInt() @Min(0) @Max(6) dayOfWeek?: number;
  @IsOptional() @IsString() @Matches(/^([01]\d|2[0-3]):[0-5]\d$/) startTime?: string;
  @IsOptional() @IsString() @Matches(/^([01]\d|2[0-3]):[0-5]\d$/) endTime?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(10) @Max(180) slotMinutes?: number;
  @IsOptional() @IsEnum(ConsultationMode) mode?: ConsultationMode;
  @IsOptional() @IsBoolean() active?: boolean;
}

export class SubmitDoctorProfileDto {
  @IsBoolean() declarationAccepted!: boolean;
}

export class ReviewDoctorDto {
  @IsOptional() @IsString() @MaxLength(1500) notes?: string;
}

export class RejectDoctorDto {
  @IsString() @MinLength(5) @MaxLength(1500) reason!: string;
}

export class ReviewDocumentDto {
  @IsBoolean() verified!: boolean;
  @IsOptional() @IsString() @MaxLength(800) note?: string;
}

export class DoctorDocumentTypeDto {
  @IsEnum(DoctorDocumentType) type!: DoctorDocumentType;
}

export class AdminDoctorStatusQueryDto {
  @IsOptional() @IsEnum(DoctorVerificationStatus) status?: DoctorVerificationStatus;
}
