import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import { Roles } from '../common/decorators/roles.decorator';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { CreateFamilyMemberDto, UpdatePatientDto } from './patients.dto';
import { PatientsService } from './patients.service';

@Controller('patients')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(UserRole.PATIENT)
export class PatientsController {
  constructor(private patients: PatientsService) {}
  @Get('me') me(@CurrentUser() user: any) { return this.patients.getMe(user.id); }
  @Patch('me') update(@CurrentUser() user: any, @Body() dto: UpdatePatientDto) { return this.patients.updateMe(user.id, dto); }
  @Get('me/family') family(@CurrentUser() user: any) { return this.patients.family(user.id); }
  @Post('me/family') add(@CurrentUser() user: any, @Body() dto: CreateFamilyMemberDto) { return this.patients.addFamily(user.id, dto); }
  @Delete('me/family/:id') remove(@CurrentUser() user: any, @Param('id') id: string) { return this.patients.removeFamily(user.id, id); }
}
