import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PrismaService } from '../prisma.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { PatientsController } from './patients.controller';
import { PatientsService } from './patients.service';
@Module({ imports: [JwtModule.register({})], controllers: [PatientsController], providers: [PatientsService, PrismaService, JwtAuthGuard, RolesGuard] })
export class PatientsModule {}
