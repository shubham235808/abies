import { IsDateString, IsEmail, IsOptional, IsString, Matches, MaxLength } from 'class-validator';

export class UpdatePatientDto {
  @IsOptional() @IsString() @MaxLength(80) firstName?: string;
  @IsOptional() @IsString() @MaxLength(80) lastName?: string;
  @IsOptional() @IsDateString() dateOfBirth?: string;
  @IsOptional() @IsString() @MaxLength(30) gender?: string;
  @IsOptional() @IsString() @MaxLength(100) city?: string;
  @IsOptional() @IsString() @MaxLength(50) preferredLanguage?: string;
  @IsOptional() @Matches(/^(?:\+91)?[6-9]\d{9}$/) emergencyContact?: string;
  @IsOptional() @IsEmail() email?: string;
}

export class CreateFamilyMemberDto {
  @IsString() @MaxLength(120) name!: string;
  @IsString() @MaxLength(50) relation!: string;
  @IsOptional() @IsDateString() dateOfBirth?: string;
  @IsOptional() @IsString() @MaxLength(30) gender?: string;
  @IsOptional() @Matches(/^(?:\+91)?[6-9]\d{9}$/) mobile?: string;
}
