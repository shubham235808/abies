import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { CreateFamilyMemberDto, UpdatePatientDto } from './patients.dto';

@Injectable()
export class PatientsService {
  constructor(private prisma: PrismaService) {}

  async getMe(userId: string) {
    const user = await this.prisma.user.findUnique({ where: { id: userId }, include: { patientProfile: { include: { familyMembers: true } } } });
    if (!user?.patientProfile) throw new NotFoundException('Patient profile not found');
    return { id: user.id, mobile: user.mobile, email: user.email, role: user.role, profile: user.patientProfile };
  }

  async updateMe(userId: string, dto: UpdatePatientDto) {
    const profile = await this.prisma.patientProfile.findUnique({ where: { userId } });
    if (!profile) throw new NotFoundException('Patient profile not found');
    if (dto.email !== undefined) await this.prisma.user.update({ where: { id: userId }, data: { email: dto.email || null } });
    return this.prisma.patientProfile.update({ where: { userId }, data: {
      firstName: dto.firstName, lastName: dto.lastName,
      dateOfBirth: dto.dateOfBirth ? new Date(dto.dateOfBirth) : undefined,
      gender: dto.gender, city: dto.city, preferredLanguage: dto.preferredLanguage,
      emergencyContact: dto.emergencyContact,
    }});
  }

  async family(userId: string) {
    const profile = await this.prisma.patientProfile.findUnique({ where: { userId }, include: { familyMembers: true } });
    if (!profile) throw new NotFoundException('Patient profile not found');
    return profile.familyMembers;
  }

  async addFamily(userId: string, dto: CreateFamilyMemberDto) {
    const profile = await this.prisma.patientProfile.findUnique({ where: { userId } });
    if (!profile) throw new NotFoundException('Patient profile not found');
    return this.prisma.familyMember.create({ data: {
      patientProfileId: profile.id, name: dto.name, relation: dto.relation,
      dateOfBirth: dto.dateOfBirth ? new Date(dto.dateOfBirth) : undefined,
      gender: dto.gender, mobile: dto.mobile,
    }});
  }

  async removeFamily(userId: string, id: string) {
    const member = await this.prisma.familyMember.findUnique({ where: { id }, include: { patientProfile: true } });
    if (!member || member.patientProfile.userId !== userId) throw new NotFoundException('Family member not found');
    await this.prisma.familyMember.delete({ where: { id } });
    return { ok: true };
  }
}
