import { CallHandler, ExecutionContext, Injectable, NestInterceptor } from '@nestjs/common';
import { Observable, finalize } from 'rxjs';
import { PrismaService } from '../../prisma.service';

@Injectable()
export class AuditInterceptor implements NestInterceptor {
  constructor(private prisma: PrismaService) {}
  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const req = context.switchToHttp().getRequest();
    const res = context.switchToHttp().getResponse();
    const started = Date.now();
    return next.handle().pipe(finalize(() => {
      if (req.method === 'GET' && req.path === '/api/v1/health') return;
      void this.prisma.auditEvent.create({ data: {
        userId: req.user?.id,
        sessionId: req.user?.sid,
        eventType: 'HTTP_REQUEST',
        action: `${req.method} ${req.path}`,
        method: req.method,
        path: req.path,
        statusCode: res.statusCode,
        ip: req.ip,
        userAgent: req.headers['user-agent'],
        metadata: { durationMs: Date.now() - started },
      }}).catch(() => undefined);
    }));
  }
}
