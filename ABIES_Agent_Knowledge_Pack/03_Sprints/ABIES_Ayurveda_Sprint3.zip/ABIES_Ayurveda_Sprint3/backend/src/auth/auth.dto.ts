import { IsBoolean, IsEnum, IsOptional, IsString, Length, Matches } from 'class-validator';
import { UserRole } from '@prisma/client';

export class RequestOtpDto {
  @IsString()
  @Matches(/^(?:\+91)?[6-9]\d{9}$/, { message: 'Enter a valid Indian mobile number' })
  mobile!: string;

  @IsEnum(UserRole)
  role!: UserRole;
}

export class VerifyOtpDto {
  @IsString() requestId!: string;
  @IsString() @Length(6, 6) otp!: string;
  @IsBoolean() acceptedTerms!: boolean;
}

export class VerifyMfaDto {
  @IsString() @Length(6, 6) code!: string;
}

export class RefreshDto {
  @IsOptional() @IsString() refreshToken?: string;
}
