import { Body, Controller, Get, Post, Req, Res, UseGuards } from '@nestjs/common';
import { Request, Response } from 'express';
import { AuthService } from './auth.service';
import { RequestOtpDto, VerifyMfaDto, VerifyOtpDto } from './auth.dto';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { CurrentUser } from '../common/decorators/current-user.decorator';

@Controller('auth')
export class AuthController {
  constructor(private auth: AuthService) {}

  @Post('request-otp')
  requestOtp(@Body() dto: RequestOtpDto) {
    return this.auth.requestOtp(dto.mobile, dto.role);
  }

  @Post('verify-otp')
  async verifyOtp(@Body() dto: VerifyOtpDto, @Req() req: Request, @Res({ passthrough: true }) res: Response) {
    const result = await this.auth.verifyOtp(dto.requestId, dto.otp, dto.acceptedTerms, { ip: req.ip, userAgent: req.headers['user-agent'] });
    this.setCookies(res, result.accessToken, result.refreshToken);
    return { user: result.user, mfaRequired: result.mfaRequired };
  }

  @Post('refresh')
  async refresh(@Req() req: Request, @Res({ passthrough: true }) res: Response) {
    const result = await this.auth.refresh(req.cookies?.abies_refresh);
    this.setCookies(res, result.accessToken, result.refreshToken);
    return { ok: true };
  }

  @UseGuards(JwtAuthGuard)
  @Post('mfa/verify')
  async verifyMfa(@CurrentUser() user: any, @Body() dto: VerifyMfaDto, @Res({ passthrough: true }) res: Response) {
    const result = await this.auth.verifyAdminMfa(user, dto.code);
    res.cookie('abies_access', result.accessToken, this.accessCookieOptions());
    return { ok: true };
  }

  @UseGuards(JwtAuthGuard)
  @Get('me')
  me(@CurrentUser() user: any) { return { user }; }

  @UseGuards(JwtAuthGuard)
  @Post('logout')
  async logout(@CurrentUser() user: any, @Res({ passthrough: true }) res: Response) {
    await this.auth.logout(user.sid);
    res.clearCookie('abies_access', this.baseCookieOptions());
    res.clearCookie('abies_refresh', this.baseCookieOptions());
    return { ok: true };
  }

  private setCookies(res: Response, access: string, refresh: string) {
    res.cookie('abies_access', access, this.accessCookieOptions());
    res.cookie('abies_refresh', refresh, { ...this.baseCookieOptions(), maxAge: 7 * 86400000 });
  }
  private baseCookieOptions(): any {
    return { httpOnly: true, secure: process.env.COOKIE_SECURE === 'true', sameSite: 'lax', path: '/', domain: process.env.COOKIE_DOMAIN || undefined };
  }
  private accessCookieOptions(): any { return { ...this.baseCookieOptions(), maxAge: 15 * 60 * 1000 }; }
}
