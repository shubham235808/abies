import { ConsultationMode, DoctorVerificationStatus, PrismaClient, UserRole } from '@prisma/client';

const prisma = new PrismaClient();

const doctorFixtures = [
  {
    mobile: '+919876543221', slug: 'ananya-sharma', firstName: 'Ananya', lastName: 'Sharma',
    primaryQualification: 'BAMS', highestQualification: 'MD (Ayurveda)', yearsExperience: 14,
    council: 'State Board / Council', reg: 'AY-DEMO-1001', specialties: ['Digestive care','Lifestyle disorders','Women’s wellness'],
    languages: ['Hindi','English'], modes: [ConsultationMode.VIDEO, ConsultationMode.CLINIC], videoFee: 699, clinicFee: 799,
    city: 'Delhi NCR', state: 'Delhi', rating: 4.9, reviews: 426,
    bio: 'Ayurveda physician focused on structured digestive, lifestyle and women’s wellness care with longitudinal follow-up.'
  },
  {
    mobile: '+919876543222', slug: 'raghav-menon', firstName: 'Raghav', lastName: 'Menon',
    primaryQualification: 'BAMS', highestQualification: 'MD (Panchakarma)', yearsExperience: 11,
    council: 'State Board / Council', reg: 'AY-DEMO-1002', specialties: ['Panchakarma','Joint care','Stress & sleep'],
    languages: ['English','Hindi','Malayalam'], modes: [ConsultationMode.VIDEO, ConsultationMode.CLINIC], videoFee: 749, clinicFee: 849,
    city: 'Bengaluru', state: 'Karnataka', rating: 4.8, reviews: 318,
    bio: 'Panchakarma practitioner with emphasis on physician-led therapy planning, musculoskeletal care and sleep support.'
  },
  {
    mobile: '+919876543223', slug: 'meera-joshi', firstName: 'Meera', lastName: 'Joshi',
    primaryQualification: 'BAMS', highestQualification: 'MS (Ayurveda)', yearsExperience: 9,
    council: 'State Board / Council', reg: 'AY-DEMO-1003', specialties: ['Women’s health','Skin care','Nutrition'],
    languages: ['Marathi','Hindi','English'], modes: [ConsultationMode.VIDEO], videoFee: 649, clinicFee: null,
    city: 'Pune', state: 'Maharashtra', rating: 4.9, reviews: 241,
    bio: 'Ayurveda clinician focused on women’s health, skin concerns and sustainable nutrition routines.'
  },
  {
    mobile: '+919876543224', slug: 'arvind-kulkarni', firstName: 'Arvind', lastName: 'Kulkarni',
    primaryQualification: 'BAMS', highestQualification: 'MD (Kayachikitsa)', yearsExperience: 18,
    council: 'State Board / Council', reg: 'AY-DEMO-1004', specialties: ['Metabolic wellness','Respiratory care','Senior care'],
    languages: ['Hindi','English','Marathi'], modes: [ConsultationMode.VIDEO, ConsultationMode.CLINIC], videoFee: 899, clinicFee: 999,
    city: 'Mumbai', state: 'Maharashtra', rating: 4.7, reviews: 581,
    bio: 'Senior Ayurveda physician with experience in long-term metabolic, respiratory and older-adult care plans.'
  },
  {
    mobile: '+919876543225', slug: 'nisha-verma', firstName: 'Nisha', lastName: 'Verma',
    primaryQualification: 'BAMS', highestQualification: 'MD (Ayurveda)', yearsExperience: 12,
    council: 'State Board / Council', reg: 'AY-DEMO-1005', specialties: ['Digestive care','Headache support','Women’s wellness'],
    languages: ['Hindi','English'], modes: [ConsultationMode.VIDEO], videoFee: 599, clinicFee: null,
    city: 'Jaipur', state: 'Rajasthan', rating: 4.8, reviews: 205,
    bio: 'Ayurveda practitioner providing structured care plans for digestive, headache and women’s wellness concerns.'
  },
  {
    mobile: '+919876543226', slug: 'kunal-iyer', firstName: 'Kunal', lastName: 'Iyer',
    primaryQualification: 'BAMS', highestQualification: 'MD (Panchakarma)', yearsExperience: 10,
    council: 'State Board / Council', reg: 'AY-DEMO-1006', specialties: ['Panchakarma','Pain management','Lifestyle care'],
    languages: ['English','Tamil','Hindi'], modes: [ConsultationMode.VIDEO, ConsultationMode.CLINIC], videoFee: 699, clinicFee: 799,
    city: 'Chennai', state: 'Tamil Nadu', rating: 4.8, reviews: 197,
    bio: 'Panchakarma practitioner combining therapy planning with ongoing lifestyle and pain-management follow-up.'
  },
];

async function main() {
  const artifacts = [
    { key: 'terms', version: '1.0', title: 'ABIES Platform Terms', bodyUrl: '/terms' },
    { key: 'privacy', version: '1.0', title: 'ABIES Privacy Notice', bodyUrl: '/privacy' },
  ];
  for (const artifact of artifacts) {
    await prisma.consentArtifact.upsert({
      where: { key_version: { key: artifact.key, version: artifact.version } },
      update: { title: artifact.title, bodyUrl: artifact.bodyUrl, active: true },
      create: artifact,
    });
  }

  const coreUsers = [
    { mobile: '+919876543210', role: UserRole.PATIENT, firstName: 'Demo', lastName: 'Patient' },
    { mobile: '+919876543211', role: UserRole.DOCTOR },
    { mobile: '+919876543212', role: UserRole.PARTNER },
    { mobile: '+919876543213', role: UserRole.SUPPORT },
    { mobile: '+919876543214', role: UserRole.ADMIN, mfaEnabled: true },
  ];

  for (const item of coreUsers) {
    const user = await prisma.user.upsert({
      where: { mobile: item.mobile },
      update: { role: item.role, mfaEnabled: item.mfaEnabled ?? false },
      create: { mobile: item.mobile, role: item.role, mfaEnabled: item.mfaEnabled ?? false },
    });
    if (item.role === UserRole.PATIENT) {
      await prisma.patientProfile.upsert({
        where: { userId: user.id },
        update: {},
        create: { userId: user.id, firstName: item.firstName, lastName: item.lastName, city: 'Agra' },
      });
    }
    if (item.role === UserRole.DOCTOR) {
      await prisma.doctorProfile.upsert({
        where: { userId: user.id },
        update: {},
        create: { userId: user.id, slug: 'doctor-demo-onboarding' },
      });
    }
  }

  for (const fixture of doctorFixtures) {
    const user = await prisma.user.upsert({
      where: { mobile: fixture.mobile },
      update: { role: UserRole.DOCTOR },
      create: { mobile: fixture.mobile, role: UserRole.DOCTOR },
    });
    const profile = await prisma.doctorProfile.upsert({
      where: { userId: user.id },
      update: {
        slug: fixture.slug, title: 'Dr.', firstName: fixture.firstName, lastName: fixture.lastName,
        bio: fixture.bio, registrationCouncil: fixture.council, registrationNumber: fixture.reg,
        primaryQualification: fixture.primaryQualification, highestQualification: fixture.highestQualification,
        yearsExperience: fixture.yearsExperience, specialties: fixture.specialties, languages: fixture.languages,
        consultationModes: fixture.modes, videoFee: fixture.videoFee, clinicFee: fixture.clinicFee,
        rating: fixture.rating, reviewCount: fixture.reviews, verificationStatus: DoctorVerificationStatus.APPROVED,
        isDiscoverable: true, reviewedAt: new Date(), isAcceptingNewPatients: true,
      },
      create: {
        userId: user.id, slug: fixture.slug, title: 'Dr.', firstName: fixture.firstName, lastName: fixture.lastName,
        bio: fixture.bio, registrationCouncil: fixture.council, registrationNumber: fixture.reg,
        primaryQualification: fixture.primaryQualification, highestQualification: fixture.highestQualification,
        yearsExperience: fixture.yearsExperience, specialties: fixture.specialties, languages: fixture.languages,
        consultationModes: fixture.modes, videoFee: fixture.videoFee, clinicFee: fixture.clinicFee,
        rating: fixture.rating, reviewCount: fixture.reviews, verificationStatus: DoctorVerificationStatus.APPROVED,
        isDiscoverable: true, submittedAt: new Date(), reviewedAt: new Date(), isAcceptingNewPatients: true,
      },
    });

    await prisma.doctorClinic.deleteMany({ where: { doctorProfileId: profile.id } });
    await prisma.doctorClinic.create({ data: {
      doctorProfileId: profile.id, name: `${fixture.firstName} Ayurveda Clinic`, addressLine1: 'Demo clinic address',
      city: fixture.city, state: fixture.state, postalCode: '110001', phone: fixture.mobile,
    }});

    await prisma.doctorAvailability.deleteMany({ where: { doctorProfileId: profile.id } });
    const mode = fixture.modes[0];
    await prisma.doctorAvailability.createMany({ data: [1,2,3,4,5].map(dayOfWeek => ({
      doctorProfileId: profile.id, dayOfWeek, startTime: '10:00', endTime: '13:00', slotMinutes: 30, mode,
    })) });
  }

  console.log('Sprint 3 seed complete. Dev OTP: 123456. Admin MFA: 654321.');
  console.log('Doctor onboarding account: 9876543211. Public directory seeded with six approved demo practitioners.');
}

main().finally(() => prisma.$disconnect());
