CREATE TYPE "DoctorVerificationStatus" AS ENUM ('DRAFT', 'SUBMITTED', 'UNDER_REVIEW', 'APPROVED', 'REJECTED', 'SUSPENDED');
CREATE TYPE "DoctorDocumentType" AS ENUM ('REGISTRATION_CERTIFICATE', 'DEGREE_CERTIFICATE', 'ID_PROOF', 'PROFILE_PHOTO', 'OTHER');
CREATE TYPE "DoctorDocumentStatus" AS ENUM ('PENDING', 'VERIFIED', 'REJECTED');
CREATE TYPE "ConsultationMode" AS ENUM ('VIDEO', 'CLINIC');

CREATE TABLE "DoctorProfile" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "slug" TEXT NOT NULL,
  "title" TEXT NOT NULL DEFAULT 'Dr.',
  "firstName" TEXT,
  "lastName" TEXT,
  "gender" TEXT,
  "bio" TEXT,
  "registrationCouncil" TEXT,
  "registrationNumber" TEXT,
  "registrationYear" INTEGER,
  "primaryQualification" TEXT,
  "highestQualification" TEXT,
  "yearsExperience" INTEGER,
  "specialties" TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  "languages" TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  "consultationModes" "ConsultationMode"[] NOT NULL DEFAULT ARRAY['VIDEO']::"ConsultationMode"[],
  "videoFee" INTEGER,
  "clinicFee" INTEGER,
  "rating" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "reviewCount" INTEGER NOT NULL DEFAULT 0,
  "isAcceptingNewPatients" BOOLEAN NOT NULL DEFAULT true,
  "verificationStatus" "DoctorVerificationStatus" NOT NULL DEFAULT 'DRAFT',
  "isDiscoverable" BOOLEAN NOT NULL DEFAULT false,
  "submittedAt" TIMESTAMP(3),
  "reviewedAt" TIMESTAMP(3),
  "reviewedByUserId" TEXT,
  "rejectionReason" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "DoctorProfile_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "DoctorProfile_userId_key" ON "DoctorProfile"("userId");
CREATE UNIQUE INDEX "DoctorProfile_slug_key" ON "DoctorProfile"("slug");
CREATE UNIQUE INDEX "DoctorProfile_registrationCouncil_registrationNumber_key" ON "DoctorProfile"("registrationCouncil", "registrationNumber");
CREATE INDEX "DoctorProfile_verificationStatus_isDiscoverable_idx" ON "DoctorProfile"("verificationStatus", "isDiscoverable");
CREATE INDEX "DoctorProfile_lastName_firstName_idx" ON "DoctorProfile"("lastName", "firstName");
ALTER TABLE "DoctorProfile" ADD CONSTRAINT "DoctorProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "DoctorDocument" (
  "id" TEXT NOT NULL,
  "doctorProfileId" TEXT NOT NULL,
  "type" "DoctorDocumentType" NOT NULL,
  "status" "DoctorDocumentStatus" NOT NULL DEFAULT 'PENDING',
  "originalName" TEXT NOT NULL,
  "storedName" TEXT NOT NULL,
  "mimeType" TEXT NOT NULL,
  "sizeBytes" INTEGER NOT NULL,
  "storagePath" TEXT NOT NULL,
  "reviewNote" TEXT,
  "verifiedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "DoctorDocument_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "DoctorDocument_doctorProfileId_type_idx" ON "DoctorDocument"("doctorProfileId", "type");
ALTER TABLE "DoctorDocument" ADD CONSTRAINT "DoctorDocument_doctorProfileId_fkey" FOREIGN KEY ("doctorProfileId") REFERENCES "DoctorProfile"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "DoctorClinic" (
  "id" TEXT NOT NULL,
  "doctorProfileId" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "addressLine1" TEXT NOT NULL,
  "addressLine2" TEXT,
  "city" TEXT NOT NULL,
  "state" TEXT NOT NULL,
  "postalCode" TEXT NOT NULL,
  "phone" TEXT,
  "latitude" DOUBLE PRECISION,
  "longitude" DOUBLE PRECISION,
  "active" BOOLEAN NOT NULL DEFAULT true,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "DoctorClinic_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "DoctorClinic_doctorProfileId_active_idx" ON "DoctorClinic"("doctorProfileId", "active");
CREATE INDEX "DoctorClinic_city_state_idx" ON "DoctorClinic"("city", "state");
ALTER TABLE "DoctorClinic" ADD CONSTRAINT "DoctorClinic_doctorProfileId_fkey" FOREIGN KEY ("doctorProfileId") REFERENCES "DoctorProfile"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "DoctorAvailability" (
  "id" TEXT NOT NULL,
  "doctorProfileId" TEXT NOT NULL,
  "dayOfWeek" INTEGER NOT NULL,
  "startTime" TEXT NOT NULL,
  "endTime" TEXT NOT NULL,
  "slotMinutes" INTEGER NOT NULL DEFAULT 30,
  "mode" "ConsultationMode" NOT NULL,
  "active" BOOLEAN NOT NULL DEFAULT true,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "DoctorAvailability_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "DoctorAvailability_doctorProfileId_dayOfWeek_active_idx" ON "DoctorAvailability"("doctorProfileId", "dayOfWeek", "active");
ALTER TABLE "DoctorAvailability" ADD CONSTRAINT "DoctorAvailability_doctorProfileId_fkey" FOREIGN KEY ("doctorProfileId") REFERENCES "DoctorProfile"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "DoctorVerificationAction" (
  "id" TEXT NOT NULL,
  "doctorProfileId" TEXT NOT NULL,
  "adminUserId" TEXT NOT NULL,
  "fromStatus" "DoctorVerificationStatus",
  "toStatus" "DoctorVerificationStatus" NOT NULL,
  "notes" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "DoctorVerificationAction_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "DoctorVerificationAction_doctorProfileId_createdAt_idx" ON "DoctorVerificationAction"("doctorProfileId", "createdAt");
CREATE INDEX "DoctorVerificationAction_adminUserId_createdAt_idx" ON "DoctorVerificationAction"("adminUserId", "createdAt");
ALTER TABLE "DoctorVerificationAction" ADD CONSTRAINT "DoctorVerificationAction_doctorProfileId_fkey" FOREIGN KEY ("doctorProfileId") REFERENCES "DoctorProfile"("id") ON DELETE CASCADE ON UPDATE CASCADE;
