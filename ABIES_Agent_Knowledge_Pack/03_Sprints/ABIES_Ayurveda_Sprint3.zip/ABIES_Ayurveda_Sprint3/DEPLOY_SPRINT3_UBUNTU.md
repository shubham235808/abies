# Upgrade the Existing ABIES VM from Sprint 2 to Sprint 3

Current expected VM:

- Ubuntu 26.04 LTS
- IP `192.168.1.160`
- Nginx on host
- Sprint 2 stack running with Docker Compose
- Existing directory `/opt/abies/ABIES_Ayurveda_Sprint2`

The safest upgrade keeps the **same Compose project directory name**, so the current PostgreSQL volume is reused.

## 1. Copy the package

From Windows PowerShell:

```powershell
scp .\ABIES_Ayurveda_Sprint3.zip devops@192.168.1.160:/home/devops/
```

## 2. Back up PostgreSQL before migration

On the VM:

```bash
cd /opt/abies/ABIES_Ayurveda_Sprint2
mkdir -p /home/devops/abies-backups

docker compose exec -T postgres \
  pg_dump -U abies -d abies_ayurveda \
  | gzip > /home/devops/abies-backups/abies-pre-sprint3-$(date +%Y%m%d-%H%M%S).sql.gz

ls -lh /home/devops/abies-backups/
```

## 3. Back up the current application directory

```bash
cd /opt/abies
cp -a ABIES_Ayurveda_Sprint2 ABIES_Ayurveda_Sprint2_backup_$(date +%Y%m%d-%H%M%S)
```

Save the current environment file separately:

```bash
cp /opt/abies/ABIES_Ayurveda_Sprint2/.env /home/devops/abies-sprint2.env
```

## 4. Extract Sprint 3

```bash
cd /opt/abies
unzip -o /home/devops/ABIES_Ayurveda_Sprint3.zip
```

The ZIP extracts as `ABIES_Ayurveda_Sprint3`.

Replace the application code **while retaining the old directory name**:

```bash
rm -rf /opt/abies/ABIES_Ayurveda_Sprint2
mv /opt/abies/ABIES_Ayurveda_Sprint3 /opt/abies/ABIES_Ayurveda_Sprint2
cp /home/devops/abies-sprint2.env /opt/abies/ABIES_Ayurveda_Sprint2/.env
```

Why: Docker Compose names the persistent PostgreSQL volume using the project/directory name. Keeping `ABIES_Ayurveda_Sprint2` means the existing database volume is reused rather than accidentally creating an empty database.

## 5. Add Sprint 3 environment settings

```bash
cd /opt/abies/ABIES_Ayurveda_Sprint2

grep -q '^ALLOW_DOCTOR_SELF_ONBOARDING=' .env || echo 'ALLOW_DOCTOR_SELF_ONBOARDING=true' >> .env
grep -q '^UPLOAD_DIR=' .env || echo 'UPLOAD_DIR=/app/uploads' >> .env
grep -q '^MAX_UPLOAD_MB=' .env || echo 'MAX_UPLOAD_MB=8' >> .env
```

Confirm without printing your secrets unnecessarily:

```bash
grep -E '^(NODE_ENV|FRONTEND_ORIGIN|ALLOW_DOCTOR_SELF_ONBOARDING|UPLOAD_DIR|MAX_UPLOAD_MB)=' .env
```

## 6. Build and upgrade

```bash
docker compose up -d --build
```

The API container starts with:

```text
prisma migrate deploy
```

so the Sprint 3 migration is applied automatically to the existing PostgreSQL database.

Check:

```bash
docker compose ps
docker compose logs api --tail=100
```

## 7. Seed Sprint 3 demo data

The seed is idempotent and retains Sprint 2 patient data.

```bash
docker compose exec api npm run prisma:seed
```

Expected message includes:

```text
Sprint 3 seed complete.
Doctor onboarding account: 9876543211.
Public directory seeded with six approved demo practitioners.
```

## 8. Deploy the Sprint 3 frontend

```bash
sudo rm -rf /var/www/abies-ayurveda/*

sudo cp index.html app.js styles.css manifest.webmanifest sw.js \
  /var/www/abies-ayurveda/

sudo cp -a assets /var/www/abies-ayurveda/

sudo chown -R www-data:www-data /var/www/abies-ayurveda
sudo find /var/www/abies-ayurveda -type d -exec chmod 755 {} \;
sudo find /var/www/abies-ayurveda -type f -exec chmod 644 {} \;
```

## 9. Deploy updated Nginx configuration

The Sprint 3 config includes a `10m` request-body limit for credential uploads.

```bash
sudo cp infra/nginx/abies-ayurveda.conf /etc/nginx/sites-available/abies-ayurveda
sudo nginx -t
sudo systemctl reload nginx
```

## 10. Validate health

```bash
curl -s http://127.0.0.1:3000/api/v1/health | jq
curl -s http://localhost/api/v1/health | jq
```

Expected:

```json
{
  "status": "ok",
  "service": "abies-ayurveda-api",
  "sprint": 3,
  "database": "ok"
}
```

## 11. Validate the public directory

```bash
curl -s http://localhost/api/v1/public/doctors | jq '.total, .doctors[0]'
```

Expected: six or more approved demo practitioners after seed.

## 12. Browser hard refresh

Open:

```text
http://192.168.1.160
```

Because this is a PWA and the previous Sprint 2 service worker may still exist, perform one hard refresh if the old UI remains:

- Chrome/Edge: `Ctrl+Shift+R`

The Sprint 3 service worker uses a new cache name and removes the old cache during activation.

## 13. Doctor workflow

Login:

```text
Role: Doctor
Mobile: 9876543211
OTP: 123456
```

Complete profile, upload registration + degree credentials, add availability and submit.

## 14. Admin workflow

Login:

```text
Role: Admin
Mobile: 9876543214
OTP: 123456
MFA: 654321
```

Verify the two required credentials, then approve the doctor.

## 15. Rollback note

If the application upgrade fails, do not delete Docker volumes. The pre-upgrade SQL dump and directory backup are in `/home/devops`.

Application code can be rolled back by restoring the backed-up Sprint 2 directory. Database rollback should be performed intentionally from the SQL backup only if the migration itself must be reverted.
