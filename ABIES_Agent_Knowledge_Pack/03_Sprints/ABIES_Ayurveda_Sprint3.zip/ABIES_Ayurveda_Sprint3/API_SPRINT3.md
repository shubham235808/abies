# Sprint 3 API Surface

Base path: `/api/v1`

## Public practitioner discovery

- `GET /public/doctors`
  - optional: `q`, `city`, `specialty`, `language`, `mode=VIDEO|CLINIC`, `limit`, `offset`
- `GET /public/doctors/facets`
- `GET /public/doctors/:slug`

Only approved/discoverable practitioners are returned.

## Doctor portal

Requires authenticated `DOCTOR` role.

- `GET /doctors/me`
- `PATCH /doctors/me`
- `POST /doctors/me/submit`
- `GET /doctors/me/documents`
- `POST /doctors/me/documents` — multipart fields: `type`, `file`
- `GET /doctors/me/documents/:id/download`
- `DELETE /doctors/me/documents/:id`
- `POST /doctors/me/clinics`
- `PATCH /doctors/me/clinics/:id`
- `DELETE /doctors/me/clinics/:id`
- `POST /doctors/me/availability`
- `PATCH /doctors/me/availability/:id`
- `DELETE /doctors/me/availability/:id`

## Admin practitioner verification

Requires authenticated `ADMIN` role and verified admin MFA.

- `GET /admin/doctors`
- `GET /admin/doctors?status=SUBMITTED`
- `GET /admin/doctors/:id`
- `POST /admin/doctors/:id/start-review`
- `POST /admin/doctors/:id/approve`
- `POST /admin/doctors/:id/reject`
- `POST /admin/doctors/:id/suspend`
- `POST /admin/doctors/:id/documents/:documentId/review`
- `GET /admin/doctors/:id/documents/:documentId/download`

Approval requires both the Registration Certificate and Degree Certificate to have document status `VERIFIED`.

## Existing Sprint 2 APIs retained

Identity, session refresh, patient profile, dependants, consent and role-gate APIs remain available.
