# ABIES Ayurveda Care — Sprint 2 deployment on Ubuntu ESXi VM

Target VM used in the lab: `192.168.1.160` running Ubuntu 26.04 LTS.

Sprint 2 adds a real NestJS API and PostgreSQL database behind the existing Nginx-served website.

## 1. Install Docker Engine and Compose

```bash
sudo apt update
sudo apt install -y docker.io docker-compose-v2 openssl
sudo systemctl enable --now docker
sudo usermod -aG docker devops
```

Log out and back in once after adding the group, then verify:

```bash
docker --version
docker compose version
```

## 2. Place the Sprint 2 source

Recommended path:

```bash
sudo mkdir -p /opt/abies
sudo chown -R devops:devops /opt/abies
cd /opt/abies
```

Copy and extract `ABIES_Ayurveda_Sprint2.zip` here.

Expected path:

```text
/opt/abies/ABIES_Ayurveda_Sprint2/
```

## 3. Create secure environment file

```bash
cd /opt/abies/ABIES_Ayurveda_Sprint2
cp .env.example .env

POSTGRES_PASSWORD=$(openssl rand -hex 24)
JWT_SECRET=$(openssl rand -hex 48)
OTP_PEPPER=$(openssl rand -hex 48)

sed -i "s|replace_with_strong_password|${POSTGRES_PASSWORD}|g" .env
sed -i "s|replace_with_at_least_32_random_characters|${JWT_SECRET}|g" .env
sed -i "s|replace_with_a_different_32_char_random_secret|${OTP_PEPPER}|g" .env
```

Review it:

```bash
nano .env
```

For the current HTTP LAN environment keep:

```text
COOKIE_SECURE=false
FRONTEND_ORIGIN=http://192.168.1.160
EXPOSE_DEV_OTP=true
OTP_DEV_CODE=123456
DEV_ADMIN_MFA_CODE=654321
```

Do not use development OTP/MFA codes in production.

## 4. Build and start PostgreSQL + API

```bash
docker compose up -d --build
```

Check:

```bash
docker compose ps
docker compose logs -f api
```

The API binds only to `127.0.0.1:3000`, so it is not directly exposed to the LAN.

## 5. Seed Sprint 2 demo accounts and consent versions

```bash
docker compose exec api npm run prisma:seed
```

Development identities:

| Role | Mobile | OTP | MFA |
|---|---|---|---|
| Patient | 9876543210 | 123456 | — |
| Doctor | 9876543211 | 123456 | — |
| Partner | 9876543212 | 123456 | — |
| Support | 9876543213 | 123456 | — |
| Admin | 9876543214 | 123456 | 654321 |

## 6. Publish the Sprint 2 frontend

```bash
cd /opt/abies/ABIES_Ayurveda_Sprint2
sudo rm -rf /var/www/abies-ayurveda/*
sudo cp index.html app.js styles.css manifest.webmanifest sw.js /var/www/abies-ayurveda/
sudo cp -a assets /var/www/abies-ayurveda/
sudo chown -R www-data:www-data /var/www/abies-ayurveda
```

Only web assets are published; backend source, environment files and deployment documents remain outside the Nginx document root.

## 7. Update Nginx reverse proxy

```bash
sudo cp /opt/abies/ABIES_Ayurveda_Sprint2/infra/nginx/abies-ayurveda.conf \
  /etc/nginx/sites-available/abies-ayurveda

sudo nginx -t
sudo systemctl reload nginx
```

The key route is:

```nginx
location /api/ {
    proxy_pass http://127.0.0.1:3000;
}
```

This keeps browser cookies same-origin and avoids CORS complexity.

## 8. Verify the stack

API health through Nginx:

```bash
curl -s http://localhost/api/v1/health | python3 -m json.tool
```

Expected:

```json
{
  "status": "ok",
  "service": "abies-ayurveda-api",
  "sprint": 2,
  "database": "ok"
}
```

Website:

```bash
curl -I http://localhost
```

From a laptop open:

```text
http://192.168.1.160/#/login
```

## 9. Useful operations

```bash
# status
docker compose ps

# API logs
docker compose logs -f api

# PostgreSQL logs
docker compose logs -f postgres

# restart
docker compose restart api

# stop stack
docker compose down

# stop without deleting PostgreSQL data
docker compose down

# DATABASE DESTRUCTIVE — do not use unless intentionally resetting
docker compose down -v
```

## 10. Sprint 2 exit checks

- OTP login creates/authenticates a patient.
- Session cookies are HTTP-only.
- Access-token expiry can be refreshed from the refresh session.
- Patient can update profile.
- Patient can add/remove family members.
- Doctor/Partner/Support role gates enforce server-side RBAC.
- Admin route requires the second MFA challenge.
- Terms/privacy acceptance is stored as versioned consent records.
- API requests create baseline audit events.
