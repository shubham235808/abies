# ABIES Ayurveda Care — Sprint 2

This package upgrades the Sprint 1 static/PWA prototype with the first real backend capability.

## Sprint 2 scope

- NestJS API
- PostgreSQL + Prisma data model
- OTP authentication
- HTTP-only access/refresh session cookies
- Patient account creation
- Patient profile
- Family/dependant profiles
- Server-side RBAC for Patient, Doctor, Partner, Support and Admin
- Admin MFA development path
- Versioned Terms/Privacy consent records
- Baseline audit trail
- Same-origin Nginx `/api/` reverse proxy
- Updated website login/dashboard using the API

See `DEPLOY_SPRINT2_UBUNTU.md` for deployment commands.
