# Sprint 2 smoke/UAT checklist

1. `GET /api/v1/health` returns HTTP 200 and database=ok.
2. Patient OTP request for `9876543210` returns a challenge in development.
3. Wrong OTP is rejected and attempt counter increments.
4. OTP `123456` authenticates the patient and sets HTTP-only cookies.
5. Reloading the browser preserves the server session.
6. Patient dashboard reads the profile from PostgreSQL.
7. Patient profile updates persist across browser refresh.
8. Add one family member; confirm it persists after refresh.
9. Remove the family member; confirm it is deleted.
10. Doctor demo login can access `/access/doctor` but not `/access/admin`.
11. Support demo login can access `/access/support` but not `/access/doctor`.
12. Admin OTP login requires the second MFA challenge.
13. Admin MFA `654321` enables `/access/admin`.
14. Consent records exist for the authenticated patient.
15. Audit events are inserted for API requests.
16. Logout revokes the session and clears cookies.
