import { PrismaClient, UserRole } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const artifacts = [
    { key: 'terms', version: '1.0', title: 'ABIES Platform Terms', bodyUrl: '/terms' },
    { key: 'privacy', version: '1.0', title: 'ABIES Privacy Notice', bodyUrl: '/privacy' },
  ];
  for (const artifact of artifacts) {
    await prisma.consentArtifact.upsert({
      where: { key_version: { key: artifact.key, version: artifact.version } },
      update: { title: artifact.title, bodyUrl: artifact.bodyUrl, active: true },
      create: artifact,
    });
  }

  const users = [
    { mobile: '+919876543210', role: UserRole.PATIENT, firstName: 'Demo', lastName: 'Patient' },
    { mobile: '+919876543211', role: UserRole.DOCTOR },
    { mobile: '+919876543212', role: UserRole.PARTNER },
    { mobile: '+919876543213', role: UserRole.SUPPORT },
    { mobile: '+919876543214', role: UserRole.ADMIN, mfaEnabled: true },
  ];

  for (const item of users) {
    const user = await prisma.user.upsert({
      where: { mobile: item.mobile },
      update: { role: item.role, mfaEnabled: item.mfaEnabled ?? false },
      create: { mobile: item.mobile, role: item.role, mfaEnabled: item.mfaEnabled ?? false },
    });
    if (item.role === UserRole.PATIENT) {
      await prisma.patientProfile.upsert({
        where: { userId: user.id },
        update: {},
        create: { userId: user.id, firstName: item.firstName, lastName: item.lastName, city: 'Agra' },
      });
    }
  }
  console.log('Sprint 2 seed complete. Dev OTP: 123456. Admin MFA: 654321.');
}

main().finally(() => prisma.$disconnect());
