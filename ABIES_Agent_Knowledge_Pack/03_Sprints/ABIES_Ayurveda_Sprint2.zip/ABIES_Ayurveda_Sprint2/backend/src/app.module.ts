import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { AuthModule } from './auth/auth.module';
import { PatientsModule } from './patients/patients.module';
import { ConsentsModule } from './consents/consents.module';
import { HealthModule } from './health/health.module';
import { AccessController } from './access.controller';
import { PrismaService } from './prisma.service';
import { AuditInterceptor } from './common/interceptors/audit.interceptor';
import { JwtModule } from '@nestjs/jwt';
import { JwtAuthGuard } from './common/guards/jwt-auth.guard';
import { RolesGuard } from './common/guards/roles.guard';
import { MfaGuard } from './common/guards/mfa.guard';

@Module({
  imports: [ConfigModule.forRoot({ isGlobal: true }), JwtModule.register({}), AuthModule, PatientsModule, ConsentsModule, HealthModule],
  controllers: [AccessController],
  providers: [PrismaService, JwtAuthGuard, RolesGuard, MfaGuard, { provide: APP_INTERCEPTOR, useClass: AuditInterceptor }],
})
export class AppModule {}
