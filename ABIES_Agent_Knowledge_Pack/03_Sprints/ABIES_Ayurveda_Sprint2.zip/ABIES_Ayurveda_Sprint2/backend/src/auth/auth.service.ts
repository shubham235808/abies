import { BadRequestException, ForbiddenException, Injectable, UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../prisma.service';
import { UserRole } from '@prisma/client';
import { createHash, createHmac, randomBytes, randomInt } from 'crypto';

@Injectable()
export class AuthService {
  constructor(private prisma: PrismaService, private jwt: JwtService, private config: ConfigService) {}

  normalizeMobile(raw: string) {
    const digits = raw.replace(/\D/g, '');
    const ten = digits.length === 12 && digits.startsWith('91') ? digits.slice(2) : digits;
    if (!/^[6-9]\d{9}$/.test(ten)) throw new BadRequestException('Invalid mobile number');
    return `+91${ten}`;
  }

  private otpHash(mobile: string, otp: string) {
    return createHmac('sha256', this.config.getOrThrow('OTP_PEPPER')).update(`${mobile}:${otp}`).digest('hex');
  }
  private tokenHash(token: string) { return createHash('sha256').update(token).digest('hex'); }
  private bool(name: string, fallback = false) { return String(this.config.get(name) ?? fallback).toLowerCase() === 'true'; }

  async requestOtp(rawMobile: string, role: UserRole) {
    const mobile = this.normalizeMobile(rawMobile);
    if (role !== UserRole.PATIENT) {
      const user = await this.prisma.user.findUnique({ where: { mobile } });
      if (!user || user.role !== role) throw new ForbiddenException('This account is not enabled for the selected role');
    }
    const cooldown = Number(this.config.get('OTP_COOLDOWN_SECONDS') ?? 30);
    const recent = await this.prisma.otpChallenge.findFirst({ where: { mobile }, orderBy: { createdAt: 'desc' } });
    if (recent && Date.now() - recent.createdAt.getTime() < cooldown * 1000) throw new BadRequestException('Please wait before requesting another OTP');

    const devCode = this.config.get<string>('OTP_DEV_CODE');
    const otp = this.config.get('NODE_ENV') !== 'production' && devCode ? devCode : String(randomInt(100000, 1000000));
    const ttl = Number(this.config.get('OTP_TTL_SECONDS') ?? 300);
    const challenge = await this.prisma.otpChallenge.create({ data: {
      mobile, role, codeHash: this.otpHash(mobile, otp), maxAttempts: Number(this.config.get('OTP_MAX_ATTEMPTS') ?? 5),
      expiresAt: new Date(Date.now() + ttl * 1000),
    }});
    return { requestId: challenge.id, expiresInSeconds: ttl, ...((this.config.get('NODE_ENV') !== 'production' && this.bool('EXPOSE_DEV_OTP')) ? { devOtp: otp } : {}) };
  }

  async verifyOtp(requestId: string, otp: string, acceptedTerms: boolean, meta: { ip?: string; userAgent?: string }) {
    if (!acceptedTerms) throw new BadRequestException('Terms and privacy notice must be accepted');
    const challenge = await this.prisma.otpChallenge.findUnique({ where: { id: requestId } });
    if (!challenge || challenge.consumedAt || challenge.expiresAt <= new Date()) throw new UnauthorizedException('OTP challenge expired or invalid');
    if (challenge.attempts >= challenge.maxAttempts) throw new UnauthorizedException('Too many OTP attempts');
    if (challenge.codeHash !== this.otpHash(challenge.mobile, otp)) {
      await this.prisma.otpChallenge.update({ where: { id: challenge.id }, data: { attempts: { increment: 1 } } });
      throw new UnauthorizedException('Incorrect OTP');
    }
    await this.prisma.otpChallenge.update({ where: { id: challenge.id }, data: { consumedAt: new Date() } });

    let user = await this.prisma.user.findUnique({ where: { mobile: challenge.mobile }, include: { patientProfile: true } });
    if (!user) {
      if (challenge.role !== UserRole.PATIENT) throw new ForbiddenException('Account must be provisioned by an administrator');
      user = await this.prisma.user.create({ data: { mobile: challenge.mobile, role: UserRole.PATIENT, patientProfile: { create: {} } }, include: { patientProfile: true } });
    }
    if (user.role !== challenge.role) throw new ForbiddenException('Selected role does not match this account');

    const artifacts = await this.prisma.consentArtifact.findMany({ where: { active: true, required: true } });
    for (const artifact of artifacts) {
      await this.prisma.consentRecord.upsert({
        where: { userId_artifactId: { userId: user.id, artifactId: artifact.id } },
        update: { withdrawnAt: null, acceptedAt: new Date(), ip: meta.ip, userAgent: meta.userAgent },
        create: { userId: user.id, artifactId: artifact.id, ip: meta.ip, userAgent: meta.userAgent },
      });
    }

    const refreshToken = randomBytes(48).toString('base64url');
    const refreshDays = Number(this.config.get('REFRESH_TTL_DAYS') ?? 7);
    const needsMfa = user.role === UserRole.ADMIN && this.bool('ADMIN_MFA_REQUIRED', true);
    const session = await this.prisma.session.create({ data: {
      userId: user.id, refreshTokenHash: this.tokenHash(refreshToken), mfaVerified: !needsMfa,
      expiresAt: new Date(Date.now() + refreshDays * 86400000), ip: meta.ip, userAgent: meta.userAgent,
    }});
    const accessToken = await this.signAccess(user.id, user.role, session.id, session.mfaVerified);
    return { user: this.publicUser(user), session, accessToken, refreshToken, mfaRequired: needsMfa };
  }

  async refresh(rawRefresh: string | undefined) {
    if (!rawRefresh) throw new UnauthorizedException('Refresh token missing');
    const session = await this.prisma.session.findUnique({ where: { refreshTokenHash: this.tokenHash(rawRefresh) }, include: { user: true } });
    if (!session || session.revokedAt || session.expiresAt <= new Date() || session.user.status !== 'ACTIVE') throw new UnauthorizedException('Refresh session is not active');
    const newRefresh = randomBytes(48).toString('base64url');
    await this.prisma.session.update({ where: { id: session.id }, data: { refreshTokenHash: this.tokenHash(newRefresh) } });
    return { accessToken: await this.signAccess(session.userId, session.user.role, session.id, session.mfaVerified), refreshToken: newRefresh };
  }

  async verifyAdminMfa(user: any, code: string) {
    if (user.role !== UserRole.ADMIN) throw new ForbiddenException('MFA challenge is only required for administrators');
    if (this.config.get('NODE_ENV') === 'production') throw new ForbiddenException('Production MFA provider is not configured yet');
    if (code !== String(this.config.get('DEV_ADMIN_MFA_CODE') ?? '654321')) throw new UnauthorizedException('Incorrect MFA code');
    const session = await this.prisma.session.update({ where: { id: user.sid }, data: { mfaVerified: true } });
    return { accessToken: await this.signAccess(user.id, user.role, user.sid, true), session };
  }

  async logout(sessionId: string) { await this.prisma.session.updateMany({ where: { id: sessionId }, data: { revokedAt: new Date() } }); }

  private async signAccess(userId: string, role: UserRole, sid: string, mfa: boolean) {
    return this.jwt.signAsync({ sub: userId, role, sid, mfa }, { secret: this.config.getOrThrow('JWT_SECRET'), expiresIn: Number(this.config.get('JWT_ACCESS_TTL_SECONDS') ?? 900) });
  }

  publicUser(user: any) {
    return { id: user.id, mobile: user.mobile, role: user.role, email: user.email, profile: user.patientProfile ?? undefined };
  }
}
