#!/usr/bin/env bash
set -euo pipefail
BASE="${1:-http://localhost/api/v1}"
echo "[1/3] Health"
curl -fsS "$BASE/health"; echo
echo "[2/3] Consent catalogue"
curl -fsS "$BASE/consents/current"; echo
echo "[3/3] Request patient OTP"
curl -fsS -X POST "$BASE/auth/request-otp" -H 'Content-Type: application/json' -d '{"mobile":"9876543210","role":"PATIENT"}'; echo
echo "Smoke checks passed. Complete OTP verification in the browser."
