# Sprint 2 API surface

Base URL: `/api/v1`

## Public

- `GET /health`
- `GET /consents/current`
- `POST /auth/request-otp`
- `POST /auth/verify-otp`
- `POST /auth/refresh`

## Authenticated

- `GET /auth/me`
- `POST /auth/logout`
- `POST /auth/mfa/verify`
- `GET /consents/me`

## Patient role

- `GET /patients/me`
- `PATCH /patients/me`
- `GET /patients/me/family`
- `POST /patients/me/family`
- `DELETE /patients/me/family/:id`

## RBAC validation gates

- `GET /access/doctor`
- `GET /access/partner`
- `GET /access/support`
- `GET /access/admin` — ADMIN + MFA

Authentication uses same-origin HTTP-only cookies (`abies_access`, `abies_refresh`).
